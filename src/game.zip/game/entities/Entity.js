class Entity {
  constructor() {}
}